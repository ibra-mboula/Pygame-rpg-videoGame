import pygame
from pygame.math import Vector2 as vector


class Sprite(pygame.sprite.Sprite):
    def __init__(self, pos,surf, groups):
        
        # j'appel le constructeur de pygame.sprite.Sprite, qui ajoute le sprite au groupe all_sprites
        super().__init__(groups)
         
        # je charge l'image du sprite
        self.image = surf
        
        #pour stocker la position du sprite et sa taille ; 
        self.rect = self.image.get_rect(topleft = pos)
        
        # je cree un box de collision 
        # 0 pour que la largeur de la hitbox soit la meme que la surface du sprite 
        # -self.rect.height/3 pour que la hitbox soit plus petite que le sprite
        self.hitbox = self.rect.inflate(0, -self.rect.height/3)
    
    # pour test les positions des sprites    
    #def __str__(self):
       # return f"Sprite at {self.rect.topleft}"

#! construction des projectiles
class Bullet(pygame.sprite.Sprite):
	def __init__(self, pos, direction, surf, groups):
		super().__init__(groups)
		self.image = surf
		self.rect = self.image.get_rect(center = pos)

		# float based movement
		self.pos = vector(*pos)
		self.direction = vector(*direction)
		self.speed = 100

	def update(self,dt):
		self.pos += self.direction * self.speed * dt
		self.rect.center = (round(self.pos.x),round(self.pos.y))
		