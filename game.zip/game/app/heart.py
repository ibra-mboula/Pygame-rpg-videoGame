
import pygame
import sys

from player import Player
from pygame.math import Vector2 as vector
from sprite import Sprite, Bullet
from monster import Coffin, Coyote
from pytmx.util_pygame import load_pygame
import os



#! Heart -----------------------------------------------------------------------
#class pour gerer l'affichage des pv du joueur
class Heart(pygame.sprite.Sprite):
    def __init__(self, position):
        super().__init__() # j'appel le constructeur de la class pygame.sprite.Sprite, qui permet d'initialiser l'objt comme sprite utilisable
        self.image = pygame.image.load('pv.png').convert_alpha()
        self.rect = self.image.get_rect()# je lui donne une hitbox
        self.rect.topleft = position # je lui donne une position en haut a gauche de l'ecran
            

