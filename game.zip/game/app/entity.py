import pygame,sys
from pygame.math import Vector2 as vector
from os import walk
import os



class Entity(pygame.sprite.Sprite):     
    scale_factor = 0.6 # pour le redimensionnement des images
    def __init__(self, pos, *groups, path, obstacles): #* *pour ajouter le sprites au groupe spécifié
        super().__init__(*groups)# utile pour ajouter le sprites a plusieurs groupes, comme all_sprites  

        self.vel = pygame.Vector2(0, 0)# vitesse de l'entité

        self.obstacles = obstacles

        self.import_assets(path)
        self.frame_index = 0
        self.status = "down_idle"

        # chargement de l'image
        self.image = self.animations[self.status][self.frame_index]
        self.rect = self.image.get_rect(center=pos)

        # mouvement de base
        self.pos = vector(self.rect.center)
        self.direction = vector()
        self.speed = 100

        # collisions
        self.hitbox = self.rect.inflate(-self.rect.width *0.5, -self.rect.height / 2)
        # self.obstacles = obstacles

        # attaques
        self.attacking = False

        # health
        self.health = 10
        self.is_vulnerable = True # pour savoir si l'entité peut prendre des dégats
        self.hit_time = None 

    
        
    def import_assets(self, path):
        self.animations = {}
        for index,folder in enumerate(walk(path)):
            if index == 0:
                for name in folder[1]:
                    self.animations[name] = []
            else:
                for file_name in sorted(folder[2], key = lambda string: int(string.split(".")[0])):
                    image_path = os.path.join(folder[0], file_name)
                    #!print(image_path)
                    surface = pygame.image.load(image_path).convert_alpha()
                    _, key = os.path.split(folder[0])  # pour avoir le dernier élement du chemin

                    # Redimensionne l'image en utilisant la méthode transform.scale()
                    surface = pygame.transform.scale(surface, (int(surface.get_width() * Entity.scale_factor),
                                                            int(surface.get_height() * Entity.scale_factor)))
                    
                    self.animations[key].append(surface)

        #!print(self.animations)
    
    def move(self, dt):
        # il faut normaliser la direction pour quel ne soit pas rapide troooppp rapide au diagonale
        if self.direction.magnitude() != 0:
            self.direction = self.direction.normalize()

        # copie de la position actuelle du joueur
        prev_pos = self.pos.copy()

        # déplacement horizontal
        self.pos.x += self.direction.x * self.speed * dt
        self.hitbox.centerx = round(self.pos.x)
        self.rect.centerx = self.hitbox.centerx
        self.collision('horizontal')

        # vérification de collision après le déplacement horizontal
        if self.check_collision():
            self.pos.x = prev_pos.x
            self.hitbox.centerx = round(self.pos.x)
            self.rect.centerx = self.hitbox.centerx

        # déplacement vertical
        self.pos.y += self.direction.y * self.speed * dt
        self.hitbox.centery = round(self.pos.y)
        self.rect.centery = self.hitbox.centery
        self.collision('vertical')

        # vérification de collision après le déplacement vertical
        if self.check_collision():
            self.pos.y = prev_pos.y
            self.hitbox.centery = round(self.pos.y)
            self.rect.centery = self.hitbox.centery
            
    def collision(self, direction):
        if direction == 'horizontal':
            hits = pygame.sprite.spritecollide(self, self.obstacles, False)
            for obstacle in hits:
                if self.vel.x > 0:
                    self.pos.x = obstacle.rect.left - self.hitbox.width
                elif self.vel.x < 0:
                    self.pos.x = obstacle.rect.right
                self.hitbox.centerx = self.pos.x
                self.rect.centerx = self.hitbox.centerx
        
        elif direction == 'vertical':
            hits = pygame.sprite.spritecollide(self, self.obstacles, False)
            for obstacle in hits:
                if self.vel.y > 0:
                    self.pos.y = obstacle.rect.top - self.hitbox.height
                elif self.vel.y < 0:
                    self.pos.y = obstacle.rect.bottom
                self.hitbox.centery = self.pos.y
                self.rect.centery = self.hitbox.centery
        
        
    
    def check_collision(self):
        hits = pygame.sprite.spritecollide(self, self.obstacles, False)
        return len(hits) > 0
    
    
    def damage(self):
        if self.is_vulnerable:
            self.health -= 1
            self.is_vulnerable = False
            self.hit_time = pygame.time.get_ticks()
            
            print("dommage recu")
            #print(self.health)
    
    
    def check_death(self):
        
        if self.health <= 9:
            self.kill()
            print("he is dead")
            
            
            
    def vulnerability_timer(self):
         if not self.is_vulnerable:
                current_time = pygame.time.get_ticks()
                if current_time - self.hit_time > 400:
                    self.is_vulnerable = True
		
        

        
    	
        
        

	
