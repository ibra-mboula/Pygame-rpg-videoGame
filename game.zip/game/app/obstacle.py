

import pygame
import sys

from player import Player
from pygame.math import Vector2 as vector
from sprite import Sprite, Bullet
from monster import Coffin, Coyote
from pytmx.util_pygame import load_pygame
import os

#! OBSTACLE -----------------------------------------------------------------------
# je cree une class obstacle qui herite de la class pygame.sprite.Sprite,
# elle va me permettre de creer des objets qui vont servir de collision
class Obstacle(pygame.sprite.Sprite): 
    
    def __init__(self, x, y, width, height):
        super().__init__() # j'appel le constructeur de la class pygame.sprite.Sprite, qui permet d'initialiser l'objt comme sprite utilisable
        self.rect = pygame.Rect(x, y, width, height)
    
    