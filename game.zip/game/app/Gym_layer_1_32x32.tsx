<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="Gym_layer_1_32x32" tilewidth="32" tileheight="32" tilecount="285" columns="19">
 <image source="../Gym_layer_1_32x32.png" width="608" height="480"/>
</tileset>
