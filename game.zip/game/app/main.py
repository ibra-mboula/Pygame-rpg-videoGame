import pygame
import sys

from player import Player
from pygame.math import Vector2 as vector
from sprite import Sprite, Bullet
from monster import Coffin, Coyote
from pytmx.util_pygame import load_pygame
import os
from heart import Heart
from obstacle import Obstacle
from all_sprites import AllSprites


import subprocess

w = 1280
h = 720
screen = pygame.display.set_mode((w, h))


#! GAME -----------------------------------------------------------------------

class Game:
    #todo: initialiser le jeu *******************************
    def __init__(self):
        pygame.init() # j'initialise pygame
        
        #chargement de la musique de fond et du son de collision
        pygame.mixer.init()        
        pygame.mixer.music.load('fond.mp3')
        self.collision_sound = pygame.mixer.Sound('hit.mp3')  
        #on fait en sorte que la musique se repete en boucl tout au long de la partie d'ou le -1
        pygame.mixer.music.play(-1)
        
        self.display_surface = pygame.display.set_mode((w, h))# je cree la fenetre de jeu
        pygame.display.set_caption("PBE")# je donne un nom a la fenetre
        
        self.clock = pygame.time.Clock()# je cree une horloge pour gerer le temps dans le jeu, il sert a gerer les fps
        
        # charge l'image de la balle
        self.bullet_surf = pygame.image.load('bullet.png').convert_alpha()

        #
        self.all_sprites = AllSprites() # j'initialise le groupe de sprite, qui va servir a gerer les sprites (ajouter, supprimer, dessiner 
        #print('all sprite 1',{self.all_sprites})
        self.obstacles = pygame.sprite.Group() # j'initialise le groupe d'obstacle, qui va servir a gerer les collisions
        print('obstacle', {self.obstacles})
        self.bullets = pygame.sprite.Group() # .... qui va servir a gerer les balles
        self.monsters = pygame.sprite.Group() # .... qui va servir a gerer les monstres
        #print('all sprite 2',{self.all_sprites})
        self.current_level = 1 # pour savoir a quel niveau on est
        self.level_completed = False # pour savoir si le niveau est fini

        self.setup() # j'appel la fonction setup qui va initialiser le niveau (création des coeurs, setup level 1,2 [ des obstacles, des monstres, du joueur])

    #todo: creation des balle *******************************
    def create_bullet(self, pos, direction):
        
        bullet_sound = pygame.mixer.Sound('shotgun.mp3')  # Chargement du son de tir
        bullet_sound.play()  # Lecture du son de tir
        
        # construction de la balle (creer un sprite balle, l'ajouter au groupe de sprite et au groupe de balle)
        Bullet(pos, direction, self.bullet_surf, [self.all_sprites, self.bullets])
        
    #todo: creation d'action lorsqu'il y'a collision entre ma balle et objets du jeu *******************************
    def bullet_collision(self):
        #*collision entre balle et obstacle
        for obstacle in self.obstacles.sprites():
            #print('obstacle', {obstacle})
            #pour detecter la collision entre un sprite et un groupe de sprite, on utilise la fonction spritecollide
            # le true est comme dokill, lorsque la collision est detecté, la balle est supprimé du groupe de balle
            pygame.sprite.spritecollide(obstacle, self.bullets, True) # spritecollide(sprite, group, dokill)

        #*collision entre balle et monstre
        for monster in self.monsters.sprites():
            if pygame.sprite.spritecollide(monster, self.bullets, True): 
                monster.damage() # le monstre prend des degats
                self.collision_sound.play() # lecture du son de collision
                
        #*collision entre balle et joueur
        if pygame.sprite.spritecollide(self.Player, self.bullets, True):# spritecollide(sprite, group, dokill)
            self.Player.damage()


    #todo: pour initialiser les images des pv et des levels *******************************
    def setup(self):
        self.create_hearts()
        if self.current_level == 1:
            self.setup_level_1()
        elif self.current_level == 2:
            self.setup_level_2()

    #todo: creation du level 1 *******************************
    def setup_level_1(self):
        
        #chargement de la map
        tmxmap = load_pygame('map1.tmx')

        #.tiles permet de recuperer les tiles de la map
        #je charge mon calque 1 et 2 avec la position x et y de chaque  tile
        for x, y, surf in tmxmap.get_layer_by_name('calque1').tiles():
            Sprite((x * 32, y * 32), surf, self.all_sprites)

        for x, y, surf in tmxmap.get_layer_by_name('calque2').tiles():
            Sprite((x * 32, y * 32), surf, self.all_sprites)

        # je fais une boucle pour recuperer les objets de la map
        for obj in tmxmap.objects:
            # si l'objet est un type colliion, je cree un obstacle
            if obj.type == 'collision':
                #je construis un obstacle avec la position x, y de l'objet, sa larg et sa h
                obstacle = Obstacle(obj.x, obj.y, obj.width, obj.height)
                self.obstacles.add(obstacle) # j'ajoute l'obstacle au groupe d'obstacle

        # je vais dans le calque entities pour recuperer les perso
        for obj in tmxmap.get_layer_by_name('entities'):
            if obj.name == 'Player':
                #je construis le joueur
                self.Player = Player((obj.x, obj.y), self.all_sprites, path='Assets/player', obstacles=self.obstacles,
                                     create_bullet=self.create_bullet)
                self.Player.scale_factor = 0.6 # taille du joueur

            if obj.name == 'Coffin': 
                self.Coffin = Coffin((obj.x, obj.y), (self.all_sprites, self.monsters), path='Assets/monster/coffin',
                                     obstacles=self.obstacles, player=self.Player)

            if obj.name == 'Coyote':
               self.Coyote = Coyote((obj.x, obj.y), (self.all_sprites, self.monsters), path='Assets/monster/coyote',
                                     obstacles=self.obstacles, player=self.Player, create_bullet=self.create_bullet)

    #todo: creation du level 2 *******************************
    def setup_level_2(self):
         
        self.level_completed = False # pour que lorsque le level 2 est fini je puisse soit terminer le jeux ou soit passer au level suivant donc 3
        
        # pour eviter un bug de seperposition du levle 1 et 2 je vide les groupes
        self.all_sprites.empty()
        self.obstacles.empty()
        self.bullets.empty()
        self.monsters.empty()
        
        tmxmap = load_pygame('map2.tmx')

        for x, y, surf in tmxmap.get_layer_by_name('calque1').tiles():
            Sprite((x * 32, y * 32), surf, self.all_sprites)

        for x, y, surf in tmxmap.get_layer_by_name('calque2').tiles():
            Sprite((x * 32, y * 32), surf, self.all_sprites)

        for obj in tmxmap.objects:
            if obj.type == 'collision':
                obstacle = Obstacle(obj.x, obj.y, obj.width, obj.height)
                self.obstacles.add(obstacle)

        for obj in tmxmap.get_layer_by_name('entities'):
            if obj.name == 'Player':
                self.Player = Player((obj.x, obj.y), self.all_sprites, path='Assets/player', obstacles=self.obstacles,
                                     create_bullet=self.create_bullet)
                self.Player.scale_factor = 0.6

            if obj.name == 'Coffin':
                self.Coffin = Coffin((obj.x, obj.y), (self.all_sprites, self.monsters), path='Assets/monster/coffin',
                                     obstacles=self.obstacles, player=self.Player)

            if obj.name == 'Coyote':
                self.Coyote = Coyote((obj.x, obj.y), (self.all_sprites, self.monsters), path='Assets/monster/coyote',
                                      obstacles=self.obstacles, player=self.Player, create_bullet=self.create_bullet)

    #def check_death(self):
     #   if len(self.monsters) == 0:
      #      self.level_completed = True
      
    #todo: verifie si le joueur est dead ou si il n'ya plus de monstre dans le group de monstre *******************************       
    def check_death(self):
        
        print(f"Number of monsters: {len(self.monsters)}")  
        print(f"Leve l completed: {self.level_completed}")  
        
        if len(self.monsters) == 0 and not self.level_completed:
            self.level_completed = True
            if self.current_level == 1:
                print("-----------  fin Level 1 ----------- ")
                # Chargement du niveau 2
                self.current_level = 2
                self.setup_level_2()
            elif self.current_level == 2:
                # Fin du jeu
                print("Fin du jeu")
                
                python_executable = sys.executable
                pygame.quit()
                script_path = "main.py"  
                os.execl(python_executable, python_executable, script_path)

                #pygame.quit()
                #sys.exit()
                        
                

    #todo: reset pour vider tous les groups *******************************
    def reset(self):
        self.all_sprites.empty()
        self.obstacles.empty()
        self.bullets.empty()
        self.monsters.empty()
        self.setup()
        self.level_completed = False
        
    #todo: creation de l'image du coeur, nbr, pos et ajout au group de sprite *******************************
    def create_hearts(self):
        self.hearts = pygame.sprite.Group()
        for i in range(10): #le nombre de coeurs de mon joueur
            # coeurs en haut à droite
            heart = Heart((w - (i + 1) * 40, 10))
            self.hearts.add(heart)
    #todo: pour supprimer les coueurs de l'écran tant que le joueur est en vie et quand il est hit *******************************
    def update_hearts(self):
        # Supprime un coeur si les pv du joueur baissent
        if len(self.hearts) > self.Player.health:
            heart_to_remove = self.hearts.sprites()[-1]
            self.hearts.remove(heart_to_remove)
    
        
    # todo fonction principale du jeu
    def run(self):
        #myfont = pygame.font.SysFont('Arial', 30) # innitialisable sur l'os de raspberry

        # Chargement des images
        pause_image = pygame.image.load("pause.png")
        pause_rect = pause_image.get_rect(center=(self.display_surface.get_width() / 2, self.display_surface.get_height() / 2))

        play_image = pygame.image.load("home.png")
        play_image = pygame.transform.scale(play_image, (play_image.get_width()*4 , play_image.get_height()*4 ))
        play_rect = play_image.get_rect(center=(self.display_surface.get_width() / 2, self.display_surface.get_height() / 2))

        paused = False
        game_started = False

        while True:
            # Phase d'initialisation
            if not game_started:
                self.display_surface.blit(play_image, play_rect)# affiche l'image de home
                pygame.display.flip()# MAJ de l'affichage, pour animation fluide

                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                        game_started = True
                    if event.type == pygame.KEYDOWN and event.key == pygame.K_x:
                        pygame.quit()
                continue # passe à la prochaine itération sans exécuter le reste du code, donc si un des if est run, on ne passe pas au reste du code

            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_w:
                        paused = not paused
                    elif event.key == pygame.K_LALT:
                        self.reset()
                    elif event.key == pygame.K_x:
                        pygame.quit()
                        sys.exit()

            # Mise à jour de l'état du jeu
            if not paused and game_started:
                dt = self.clock.tick() / 800
                self.all_sprites.update(dt)
                self.bullet_collision()
                self.check_death()

            # dessine tout sur l'écran
            self.display_surface.fill("black")

            # pour dessiner la map, du joueur et des autres sprites
            if game_started:
                self.all_sprites.customize_draw(self.Player)

            
            if game_started:
                self.update_hearts()
                self.hearts.draw(self.display_surface)

            # pause
            if paused:
                self.display_surface.blit(pause_image, pause_rect)

            #print('all sprite', len(self.all_sprites), 'sprites:')
            #for sprite in self.all_sprites:
            #  print(sprite)
            
            #print('obstacle', {self.obstacles})
            #for obstacle in self.obstacles.sprites():
                 #print('obstacle', len(self.obstacles))

            # Mise à jour de l'affichage
            pygame.display.flip()

if __name__ == "__main__":
    game = Game()
    game.run()