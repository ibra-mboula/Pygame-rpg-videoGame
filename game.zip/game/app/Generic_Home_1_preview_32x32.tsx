<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="Generic_Home_1_preview_32x32" tilewidth="32" tileheight="32" tilecount="182" columns="14">
 <image source="../Generic_Home_1_preview_32x32.png" width="448" height="428"/>
</tileset>
