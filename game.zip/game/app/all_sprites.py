
import pygame
import sys

from player import Player
from pygame.math import Vector2 as vector
from sprite import Sprite, Bullet
from monster import Coffin, Coyote
from pytmx.util_pygame import load_pygame
import os

w = 1280
h = 720

#! AllSprites -----------------------------------------------------------------------
# j'herite de la class pygame.sprite.Group, qui va me permettre de creer un groupe de sprite
class AllSprites(pygame.sprite.Group): 
    def __init__(self):
        super().__init__() # appel du constructuteur pour iniatiliser l'obj comme un groupe de sprite
        self.offset = vector() # coord sprite
        self.display_surface = pygame.display.get_surface() # pour dire la surface sur laquelle on va dessiner les sprites

    def customize_draw(self, player):
        # on va centrer le sprite 
        self.offset.x = player.rect.centerx - w / 2
        self.offset.y = player.rect.centery - h / 2
        
        for sprite in self.sprites(): # pour chaque sprite dans le groupe
            offset_rect = sprite.image.get_rect(center=sprite.rect.center)#pour cree rectang a la taille de l'image
            offset_rect.center -= self.offset
            self.display_surface.blit(sprite.image, offset_rect) # je dessine l'image du sprite sur la surface de l'ecran
            