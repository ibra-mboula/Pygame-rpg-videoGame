<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="ZYo1le" tilewidth="32" tileheight="32" tilecount="270" columns="18">
 <image source="../../../../Tiledsets/Modern_Interiors_v41.3.3/5_Home_Designs/Gym_Designs/32x32/ZYo1le.png" width="604" height="480"/>
</tileset>
