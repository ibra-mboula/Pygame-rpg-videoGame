<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Walls_TILESET_A4_" tilewidth="32" tileheight="32" tilecount="528" columns="24">
 <image source="../../tiledsets/Walls_TILESET_A4_.png" width="768" height="720"/>
</tileset>
