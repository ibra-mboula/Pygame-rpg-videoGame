<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Generic_Home_1_preview_32x32" tilewidth="32" tileheight="32" tilecount="182" columns="14">
 <image source="../../tiledsets/Generic_Home_Designs/32x32/Generic_Home_1_preview_32x32.png" width="448" height="428"/>
</tileset>
