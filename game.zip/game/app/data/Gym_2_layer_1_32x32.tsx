<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Gym_2_layer_1_32x32" tilewidth="32" tileheight="32" tilecount="84" columns="12">
 <image source="../../../../Tiledsets/Modern_Interiors_v41.3.3/5_Home_Designs/Gym_Designs/32x32/Gym_2_layer_1_32x32.png" width="384" height="224"/>
</tileset>
