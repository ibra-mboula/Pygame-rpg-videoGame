<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="floor" tilewidth="32" tileheight="32" tilecount="432" columns="24">
 <image source="../../tiledsets/Floors_2_TILESET_A2_.png" width="768" height="576"/>
</tileset>
