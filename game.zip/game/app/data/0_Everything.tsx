<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="0_Everything" tilewidth="32" tileheight="32" tilecount="7832" columns="8">
 <image source="../../tiledsets/0_Everything.png" width="256" height="31344"/>
</tileset>
