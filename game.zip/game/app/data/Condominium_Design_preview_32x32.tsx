<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Condominium_Design_preview_32x32" tilewidth="32" tileheight="32" tilecount="154" columns="14">
 <image source="../../../../Tiledsets/Modern_Interiors_v41.3.3/5_Home_Designs/Condominium_Designs/32x32/Condominium_Design_preview_32x32.png" width="448" height="352"/>
</tileset>
